﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomCards
{
    class Program
    {
        enum Options
        {
            PlayCard = 1,
            ShuffleCard = 2,
            Restart = 3,
            ExitCode = 4,
        };

        static void Main(string[] args)
        {
            CardDecks deck1 = new CardDecks();
            deck1.Shuffle();
            var inputCode = Convert.ToString(Options.PlayCard);
            Console.WriteLine("*******Deck Card Preparation*******");
            Console.WriteLine("Please select any of the options mentioned below :");
            Console.WriteLine("Type" + " 1 " + "for Playing a card");
            Console.WriteLine("Type" + " 2 " + "for Shuffle the cards");
            Console.WriteLine("Type" + " 3 " + "to RESTART the game");
            Console.WriteLine("Type" + " 4 " + "to EXIT the game");

            List<Cards> myCurrentList = new List<Cards>();
            bool flag = true;
            while (inputCode != Convert.ToString(Options.ExitCode) && flag)
            {
                Console.Write("Input your code : ");
                inputCode = Console.ReadLine();
                try
                {
                    switch (Enum.GetName(typeof(Options), Convert.ToInt32(inputCode)))
                    {
                        case nameof(Options.PlayCard):
                            Cards playingCard = deck1.NewCard(myCurrentList);
                            Console.WriteLine(playingCard);
                            myCurrentList.Add(playingCard);
                            break;
                        case nameof(Options.ShuffleCard):
                            deck1.Shuffle();
                            break;
                        case nameof(Options.Restart):
                            deck1.Shuffle();
                            myCurrentList = new List<Cards>();
                            break;
                        case nameof(Options.ExitCode):
                            Console.WriteLine("Thanks for playing with us.");
                            flag = false;
                            break;
                        default:
                            Console.WriteLine("Incorrect Entry. Please try again");
                            break;
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Incorrect Entry. Please try again");
                }
                Console.WriteLine();
            }
            Console.Read();
        }
    }
}
