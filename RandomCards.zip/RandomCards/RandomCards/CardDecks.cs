﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomCards
{
    class CardDecks
    {
        int currentCard = 0;
        string[] cardFaces = { "Two", "Three", "Four", "Five", "Six","Seven","Eight",
                                    "Nine","Ten","Jack","Queen","King","Ace"};
        string[] cardTypes = { "Hearts", "Clubs", "Spades", "Diamonds" };

        readonly int totalCards = 52;

        Cards[] cards;
        Random random;
        public CardDecks()
        {
            cards = new Cards[totalCards];
            random = new Random();
            for (int i = 0; i < totalCards; i++)
            {
                string face = cardFaces[i % 13];
                string type = cardTypes[i / 13];
                cards[i] = new Cards(face, type);
            }
        }

        public void Shuffle(int remainingCards = 52)
        {
            currentCard = 0;
            for (int i = 0; i < remainingCards; i++)
            {
                int next = random.Next(remainingCards);
                Cards tmp = cards[i];
                cards[i] = cards[next];
                cards[next] = tmp;
            }
        }

        public Cards NewCard(List<Cards> myCurrentCardList)
        {
            if (currentCard < cards.Length)
            {
                Cards card = cards[currentCard++];
                return myCurrentCardList.Contains(card) ? NewCard(myCurrentCardList) : card;
            }
            else
                return null;
        }
    }
}
